import React from "react";
import "./styles.css"; // Import stylesheet

const ContactPage: React.FC = () => {
  return (
    <div>
      <h1>Contact</h1>
      <p>This is the contact page</p>
    </div>
  );
};

export default ContactPage;
