import React, { useEffect, useState } from "react";
import "./styles.css"; // Import stylesheet
import img1 from "../assets/LabRoom.png";
import img2 from "../assets/DesignRoom.png";
import img3 from "../assets/ExploringRoom.png";

const HomePage: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const texts = ["Researcher", "Designer", "Explorer", "Engineer"]; // Define the texts to rotate
  const images = [img1, img2, img3];

  useEffect(() => {
    // Trigger fade-in effect when component mounts
    setIsVisible(true);

    // Rotate text every 2 seconds
    const interval = setInterval(() => {
      setCurrentTextIndex((prevIndex) => (prevIndex + 1) % texts.length);
    }, 5000);

    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  }, []);

  // // Function to handle scroll event
  // const handleScroll = () => {
  //   updateTransform(); // Update the transform on scroll
  // };

  // useEffect(() => {
  //   window.addEventListener("scroll", handleScroll);
  //   return () => window.removeEventListener("scroll", handleScroll);
  // }, []);

  // Function to update transform property
  const updateTransform = () => {
    const scrolled = window.scrollY;
    const homeContent = document.querySelector(".home-content") as HTMLElement;

    // Shift home-content to the left based on scroll position
    homeContent.style.transform = `translateX(${-scrolled * 25}px)`;
  };

  // Call updateTransform function once when component mounts
  useEffect(() => {
    updateTransform();
  }, []);

  return (
    <div className={`home-page ${isVisible ? "fade-in" : ""}`}>
      <div className="home-content">
        <div className="intro">Hey! My name is</div>
        <h1>Jeremy Yin</h1>
        <div className="intro">I am a</div>
        <h1 className="rotating-text">{texts[currentTextIndex]}</h1>
      </div>
      <div className="home-content-right">
        <img className="rotating-photo" src={images[currentTextIndex]} alt="" />
      </div>
    </div>
  );
};

export default HomePage;
