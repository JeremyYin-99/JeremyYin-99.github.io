import React from 'react';
import './styles.css'; // Import stylesheet

const AboutPage: React.FC = () => {

    return (
        <div className="about">
            <h1>About</h1>
            <p>This is the about page</p>
        </div>
    );
};

export default AboutPage;
