import React from "react";
import "./styles.css"; // Import stylesheet

const RandPPage: React.FC = () => {
  return (
    <div>
      <h1>Research and Publications</h1>
      <p>This is the about page</p>
    </div>
  );
};

export default RandPPage;
